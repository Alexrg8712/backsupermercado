package com.proyecto.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.proyecto.models.User;



public interface IUsuarioDAO extends MongoRepository<User, Integer>{

}
