package com.proyecto.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.proyecto.models.Consolidated;


public interface IConsolidadoDAO extends MongoRepository<Consolidated, Integer> {

}
