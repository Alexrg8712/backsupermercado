package com.proyecto.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.proyecto.models.Ventas;


public interface IVentasDAO extends MongoRepository<Ventas, Integer>{

}
